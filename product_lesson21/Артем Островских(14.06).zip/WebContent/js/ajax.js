$(document).ready(function (){ //Инициализация (общ.)
	var count = 0;
	
	$(".but").on('click', function(){ //Клик по кнопке поиска
		var type = $(".type_select :selected").val();
		formOutBlock(type);
		
	});
	
	function formOutBlock(type){ //Формиование списка
		var products = new Array(4);
		$('prop').html('');
		$('').appendTo('.out');
		switch(type){
			case '1':
				products[0] = "Name1";
				products[1] = "Comedy";
				products[2] = "300";
				products[3] = "300";
				break;
			case '2':
				products[0] = "Name2";
				products[1] = "Adventure";
				products[2] = "450";
				products[3] = "600";
				break;
			case '3':
				products[0] = "Name3";
				products[1] = "Detetive";
				products[2] = "350";
				products[3] = "450";
				break;	
			case '4':
				products[0] = "Name4";
				products[1] = "Drama";
				products[2] = "300";
				products[3] = "500";
				break;
		}
		for(var i=0;i<4;i++){
			$('#'+(i+1)+'.prop').html(products[i]);
		}
		$(".toCart").show();
	}		
	
	$('input.toCart').on('click', function(){ //Добавляем в корзину
		count++;
		var query="";
			query+='name='+$('#1.prop').text();
			query+='&price='+$('#4.prop').text();
			
			alert(query);
		$.ajax({
			type:"POST",
			data: query,
			url: "/product_lesson21/addCart",
			success: function(msg){
				alert('Товар успешно добавлен в козину');
			}
		});
	});
	
	$('input.checkout').on('click',function(){ //Клик по кнопке "Оформить заказ"
		window.location.replace("/product_lesson21/cart");
	});
	
	/***************************************************************************/
	
	function appendOption (value,name){//Польз функция для создания опций
		$(".type_select").append("<option value="+value+">"+name+"</option>");
	}
	appendOption(1,"Comedy");
	appendOption(2,"Adventure");
	appendOption(3,"Detective");
	appendOption(4,"Drama");
});